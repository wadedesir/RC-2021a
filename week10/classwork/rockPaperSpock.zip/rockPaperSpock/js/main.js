document.querySelector('#check').addEventListener('click', start)
let playerChoices = ['rock', 'paper', 'scissors', 'lizard', 'spock']
  //gets value from input

function start(){
  let content = document.querySelector('.userChoice').value
  document.querySelector(`.${playerChoices[content]}`).style.color = 'green'
  // 'spock'
  console.log(content);
  fetch(`/api?playerChoice=${Number(content)}`) //instead of palindrome pass in rock paper scissor or spock variable.
  .then(response => response.json())
  .then((data) => {
    document.querySelector(`.${data.opponentChoice}Bot`).style.color = 'red'
    document.querySelector('h2').textContent = data.information // return data.information -- Who wins.
    console.log(data);
});
}

function winInformation(){
  // if ( spock beats scissors){
  //   dociment.qe... `Scissors WIN`
  // }
}
// function aiShuffle(){
//   let shuffleTimer
//   while(waitPlayer){
//
//   }
// }
