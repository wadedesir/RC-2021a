# Palindrome Checker

![alt tag](https://i.ibb.co/pWrYw9h/palidrome-Git.png)

## How It's Made:

**Tech used:** HTML, CSS, JavaScript, Node.js

This is a simple Node application that checks if the word input is a palindrome. The code that checks wether a word or phrase is a palindrome is fully server-side. The HTML and CSS are served to the client's web browser and the rest of the website's function is computed straight from the server.
