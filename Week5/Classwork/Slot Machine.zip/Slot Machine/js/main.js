/* Build a simple slot machine with minimum 5 items per reel and 3 reels
the pictures in the slot machine should visablly shuffle before one is selected  -
user should be able to bet min or max and have their total update aka how much money they have won or lost.
 two buttons or a drop down selector for how much the user wants to bet
 Min bet does $5 and Max bet does $50. They should start with $1000.
 track how much money is had through subtracting the bet from total
  Matches of the three wheels = a win just like a normal slot machine and they win 10x their bet
  if three pictures dont match up the user will lose the money that they put up to bet
  when balance reaches 0 a message alerts the user that theyve lost
*/

let balance = 1000;

let test = ['sike1', 'sike2']

alert(multiply(2,2))
